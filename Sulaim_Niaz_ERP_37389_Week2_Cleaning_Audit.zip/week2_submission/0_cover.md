# Week 2 – Price Ledger Cleaning Audit

**Student:** Sulaim Niaz  
**ERP:** 37389  
**Source file:** `teaching_prices_messy.csv`  
**Source SHA-256:** `5818dad3807487d4e37f764e5d19cbaa152edd78fe4db182eb28b087c8709d35`

## Purpose
Audit the supplied illustrative price ledger, document data-quality issues, test proposed cleaning steps on a copy, and preserve an audit trail of every decision.

## Academic-integrity note
This package was prepared with AI assistance after the source file was supplied. Therefore, `1_attempt.md` is an AI-assisted diagnostic draft and **must not be represented as an independent, pre-AI attempt or a genuine `attempt-before-AI` commit**. No pre-AI Git commit hash has been invented. If the course requires an independent first attempt, complete that separately in your own words and commit it before using AI-generated suggestions.

The data label states that these are illustrative teaching observations, not actual PBS observations.
