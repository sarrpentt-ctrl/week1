# 3. Cleaning Code Court, Audit Log and Reflection

**Student:** Sulaim Niaz  
**ERP:** 37389  
**Source SHA-256:** `5818dad3807487d4e37f764e5d19cbaa152edd78fe4db182eb28b087c8709d35`

## A. Court verdicts

The cleaning code is deliberately conservative. It works on a copy and preserves the raw price text.

| Proposed code / operation | Verdict | Evidence and reasoning |
|---|---|---|
| `work = raw.copy()` | KEEP | Protects the imported source DataFrame from direct modification |
| `pd.to_datetime(work['date'], errors='coerce')` | KEEP | Dates are consistently formatted; conversion enables date analysis. Check for newly created `NaT` values |
| `.str.replace(',', '', regex=False)` before numeric conversion | KEEP WITH CAUTION | Converts `1,250` to 1250; this assumes comma is a thousands separator. Confirm against source if possible |
| `pd.to_numeric(..., errors='coerce')` | KEEP WITH CHECK | Makes prices numeric; errors become missing and must be counted/reviewed |
| `work['item'].str.strip().str.title()` | MODIFY | It standardises `oil b` to `Oil B`; `.title()` also changes every label. Here it is acceptable for the current labels, but inspect unique values before applying generally |
| `work.drop_duplicates()` | KEEP WITH DOCUMENTATION | One exact duplicate row exists. Removing the extra copy avoids double counting; original raw file remains unchanged |
| Automatically fill missing price with mean or zero | REJECT | No evidence supports an imputed value; zero is not equivalent to missing |
| Delete price 9999 as an outlier | REJECT | It is extreme but could be a genuine observation or a data-entry error. Flag and retain pending source verification |
| Change 9999 to a guessed value | REJECT | No source evidence establishes a replacement |
| Drop the `data_label` column | REJECT | It documents that the dataset is illustrative teaching data, not actual PBS data |

## B. Audit log rows

| Step | Change / test | Result | Decision |
|---|---|---|---|
| 1 | Imported original CSV | 97 rows × 6 columns | Keep raw copy |
| 2 | Checked missing values | One missing `price` | Retain missing |
| 3 | Checked exact duplicates | One duplicate row | Remove extra copy in working data |
| 4 | Inspected item labels | `oil b` and `Oil B` | Standardise case; record |
| 5 | Inspected price formatting | `1,250` is text | Convert to numeric 1250, with thousands-separator assumption |
| 6 | Inspected extreme values | Sweetener D price 9999 | Flag and retain |
| 7 | Converted dates | `date` to datetime | Keep if no conversion failures |
| 8 | Compared before / after | See notebook summary | Confirm rows and values; no silent deletion of extreme observation |

## C. Reflection draft – personalise before submission

The audit showed me that cleaning data is not simply deleting unusual values. The missing price should remain missing because there is no evidence for a replacement. The exact duplicate can be removed from the analysis copy because all fields match an earlier observation. The `oil b` label appears to be a capitalization inconsistency, so standardising it to `Oil B` makes grouping more reliable.

The value 9999 was the most important judgement. It is very different from the other prices, but an extreme value is not automatically an error. I therefore kept and flagged it rather than deleting or replacing it without evidence. I also learned that a number stored as text can prevent numerical analysis, and that date columns should be converted to datetime.

**Before submitting:** replace or expand this reflection with your own account. In particular, state which decisions you personally made, what you learned from checking the notebook outputs, and whether your decisions differed from the AI suggestions. Do not claim independent work that you did not perform.

## D. AI-use record

AI was used to help inspect the supplied CSV, propose diagnostic checks, draft cleaning code, and explain possible decisions. All proposed changes should be checked against the notebook outputs and source data. No external or confidential personal data was supplied.
