# AI Use Log

**Student:** Sulaim Niaz  
**ERP:** 37389

## AI assistance used

AI assistance was used after the source CSV was provided to:
- inspect the dataset structure and identify potential data-quality issues;
- suggest pandas diagnostic commands;
- draft a conservative cleaning workflow for a separate copy;
- explain the reasoning behind keep, modify and reject decisions;
- prepare documentation and notebook structure.

## Important boundaries

- The original `teaching_prices_messy.csv` was preserved unchanged.
- Cleaning was performed on a separate DataFrame copy and exported to `teaching_prices_cleaned_AI_audited.csv`.
- The missing price was not imputed.
- The exact duplicate was removed from the working copy only.
- The unusual price 9999 was retained and flagged, not deleted or replaced.
- The interpretation of `1,250` as a thousands-separated number is an assumption that should be verified against an original source if one exists.
- This AI-assisted package must not be described as an independent pre-AI attempt. No pre-AI Git commit hash was fabricated.

## Student verification required

Review every notebook cell and output. Edit the reflection in `3_log_reflection.md` so it accurately describes your own decisions and learning. If your instructor requires a genuinely independent first attempt, complete and commit it separately before relying on AI assistance.
