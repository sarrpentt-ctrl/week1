# 1. Initial diagnosis and planned decisions

**Student:** Sulaim Niaz  
**ERP:** 37389  
**Source:** `teaching_prices_messy.csv`  
**SHA-256 (source file):** `5818dad3807487d4e37f764e5d19cbaa152edd78fe4db182eb28b087c8709d35`

> **Status:** AI-assisted diagnostic draft prepared after AI access. This is not an independent `attempt-before-AI` snapshot. Do not claim that it was written or committed before AI assistance.

## Dataset structure

- Rows: **97**
- Columns: **6**
- Columns: `date, item, city, price, unit, data_label`
- Initial pandas types: all six columns are `object` (text-like).
- Missing values: `1` in total, located in `price`.
- Exact duplicate rows: `1`.

## Diagnosed issues and decisions

| Issue | Evidence / how identified | Planned decision | Reason |
|---|---|---|---|
| Price column stored as text | `df.dtypes`; `price` contains the text value `1,250` | Convert a separate working price column to numeric after removing thousands separators; retain raw source column | Numeric analysis requires numeric values; keep original evidence |
| Missing price | `df.isna().sum()` reports one missing `price` | Retain as missing; investigate source if available | Do not invent a price or replace missing with zero |
| Exact duplicate | `df.duplicated().sum()` reports one; duplicate is the repeated Staple A / City 1 / 2026-01-08 / 99.5 record | Remove only the extra exact copy from the analysis copy | Exact duplicate inflates counts and may bias summaries |
| Inconsistent item capitalisation | `df['item'].value_counts()` / `.unique()` reveals `oil b` as well as `Oil B` | Standardise capitalization to `Oil B`, while recording the change | Likely a formatting inconsistency; no product identity change is inferred |
| Extreme price | Numeric conversion and sorting show Sweetener D / City 1 / 2026-01-22 / 9999 | Flag and retain; do not delete or replace without source verification | An extreme value may be genuine; deleting it silently could bias results |
| Date stored as text | `df.dtypes` reports `date` as object | Convert date in the working copy to datetime | Enables chronological sorting and time-series analysis |
| Unit and data label | `value_counts()` shows one consistent value in each column | Retain unchanged | No inconsistency detected; label explicitly says illustrative data |

## Evidence commands

```python
df.shape
df.head()
df.dtypes
df.info()
df.isna().sum()
df.duplicated().sum()
df['item'].value_counts(dropna=False)
df['price'].unique()
df.sort_values('price', ascending=False).head()
```

## Hash and commit record

- Source-file SHA-256: `5818dad3807487d4e37f764e5d19cbaa152edd78fe4db182eb28b087c8709d35`
- Git pre-AI commit: **Not created / not applicable**. This package was generated with AI assistance, so it would be dishonest to invent a pre-AI commit hash.
- To calculate a Git commit hash after making your own genuine commit, use `git rev-parse HEAD`. Only label it pre-AI if it was actually committed before AI assistance.
