Assignment 2: The Dirty Ledger
The Prices Desk  
Week 2: Loading, cleaning and data quality

Student: Sulaim Niaz
ERP: 37389
Course: ICA

Files

* 1\_attempt.md: initial diagnosis and planned decisions.
* 2\_work.ipynb: reproducible inspection, cleaning and before/after checks.
* 3\_log\_reflection.md: AI-code review, verdicts and reflection.
* teaching\_prices\_messy.csv: untouched source data.

Important note
The dataset identifies itself as illustrative teaching data, not actual PBS observations. The cleaning process preserves the original file and does not silently invent missing or suspicious prices.

